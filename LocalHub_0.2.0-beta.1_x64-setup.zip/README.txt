# LocalHub v0.2.0-beta.1 (Early Beta — Windows x64)

## Included Files
- `LocalHub_0.2.0-beta.1_x64-setup.exe` — Windows x64 NSIS setup installer (4,175,674 bytes)
- `LocalHub_0.2.0-beta.1_x64-setup.exe.sha256` — SHA-256 checksum for the installer
- `README.txt` — Installation instructions and release notes

## SHA-256 Verification
Before running the installer, verify its SHA-256 digest in PowerShell:

```powershell
Get-FileHash .\LocalHub_0.2.0-beta.1_x64-setup.exe -Algorithm SHA256
```

Expected SHA-256:
`802a05f869da5413444eb4c8c30f7c56120db3d4fbab76f945c44209a86da818`

## System Requirements
- Windows 10 or Windows 11 (x64)
- Microsoft Edge WebView2 Runtime (preinstalled on modern Windows 10/11 systems)

## Important Notes
- This early beta is an unsigned manual-install prerelease (no Authenticode code-signing certificate and no Tauri updater signature/manifest yet).
- Windows SmartScreen may warn when launching the installer; verify the SHA-256 checksum above before proceeding.
- Automatic in-app updates are disabled in this build until the maintainer configures the signed release channel.
- The previous 0.1.0 installer predates updater support and requires manual installation of this version.
- Public Hugging Face model discovery, variant inspection, and snapshot downloads are included, along with SQLite-backed settings. No local inference backend is bundled yet, so downloaded models are not executed inside LocalHub.
